# AM_Android_Wordnote_app
Android 英汉互译单词本  
wordnote  
学校移动应用开发的作业  
  

## 【功能介绍】  
·英汉互译  
·单词收藏  
  
## 【特点】  
内置有道翻译java爬虫  
transalte类中有写好相应的接口  
  
## 【注】  
个别功能点未异常处理  
各功能并未详细解耦  
后续有时间会继续完善  
请谅解......  
   
### 邮箱:amberzdh@163.com  
### wx:amberzdh
### 欢迎交流  
