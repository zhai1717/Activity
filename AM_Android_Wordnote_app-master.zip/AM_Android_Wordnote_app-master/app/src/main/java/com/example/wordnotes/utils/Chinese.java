package com.example.wordnotes.utils;

public class Chinese {
/**
 * 判断输入的词是否为中文
 * 单词本不存中文词汇
 * 用于将中文词汇在存入前排除
 */
}
